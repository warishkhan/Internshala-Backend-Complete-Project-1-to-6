const express = require('express');
const bodyParser = require('body-parser');
const storage = require('node-persist');

const app = express();
const port = 3000;

// Middleware to parse JSON data
app.use(bodyParser.json());

// Initialize node-persist asynchronously
async function initializeStorage() {
  await storage.init({
    dir: '.node-persist/storage', // Specify a directory for data storage
  });
}

// In-memory storage for student data
let students = [];

// 1. Create a POST request
app.post('/addStudent', async (req, res) => {
  await initializeStorage();

  const { studentID, studentName, GPA } = req.body;

  // Check if studentID is unique
  const isUniqueID = students.every(student => student.studentID !== studentID);

  if (!isUniqueID) {
    return res.status(400).json({ error: 'Student ID must be unique.' });
  }

  // Add student to the database
  students.push({ studentID, studentName, GPA });
  await storage.setItem('students', students);

  res.json({ message: 'Student added successfully.' });
});

// 2. Retrieve all data
app.get('/allStudents', async (req, res) => {
  await initializeStorage();

  students = (await storage.getItem('students')) || [];

   // Create an HTML template using template literals
   const htmlResponse = `
   <h1>All Students data!</h1>
     ${students.map(student => `
       <div>
         <h2>Studend id: ${student.studentID}</h2>
         <h2>Name: ${student.studentName}</h2>
         <h2>GPA: ${student.GPA}</h2>
       </div></br>
     `).join('')}
 `;
  res.send(htmlResponse);
});

// 3. Retrieve data of a particular student
app.get('/student/:studentID', async (req, res) => {
  await initializeStorage();

  students = (await storage.getItem('students')) || [];
  
  const studentID = req.params.studentID;
  const student = students.find(student => student.studentID == studentID);


  if (!student) {
    return res.status(404).json({ error: 'Student not found.' });
  }

  // Create an HTML template for the single student using template literals
  const htmlResponse = `
    <h1>Student Details</h1>
    <h2>Student ID: ${student.studentID}</h2>
    <h2>Name: ${student.studentName}</h2>
    <h2>GPA: ${student.GPA}</h2>
  `;
  res.send(htmlResponse)
});


// 4. Find the topper among the class
app.get('/topper', async (req, res) => {
  await initializeStorage();

  students = (await storage.getItem('students')) || [];

  if (students.length === 0) {
    return res.status(404).json({ error: 'No students found.' });
  }

  const topper = students.reduce((prev, current) => (prev.GPA > current.GPA ? prev : current));

  // Create an HTML template for the topper using template literals
  const htmlResponse = `
    <h1>Class Topper</h1>
    <h2>Topper ID: ${topper.studentID}</h2>
    <h2>Name: ${topper.studentName}</h2>
    <h2>GPA: ${topper.GPA}</h2>
  `;

  // Send the HTML response
  res.send(htmlResponse);
});

// Start the server
app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
