********************************************* Summery of my project *********************************************************************

batch :- 1st November 2023

Name :- Warish khan

Assignment_1_Internshala-NODE_&_EXPRESS

I have created this Student Management Database website using Node and Express.The Student Management Database website is a simple web application that allows users to add Student To Database using post api and Get student Data Using get api. It is designed with a user-friendly interface.This documentation provides an overview of the Student Management API, which allows users to perform CRUD operations on student data. The API is built using Node.js and Express, and it utilizes the node-persist library for persistent storage.

******************************************************Features***************************************************************************
Table of Contents
1. Installation
2. Endpoints
   1. Add Student
   2. Get All Students
   3. Get Student by ID
   4. Get Class Topper
3. Usage

<-----------------Installation--------------->
1. Install Node.js and npm (Node Package Manager) on your machine.
2. Clone the repository or download the code.
3. Run the following command to install dependencies:

npm install
Start the server:

node app.js
The server will be running on http://localhost:3000.

<-----------------Endpoints--------------------->
1. Add Student
. Endpoint: POST /addStudent
. Description: Add a new student to the database.
. Request Body:
  . studentID (string): Unique identifier for the student.
  . studentName (string): Name of the student.
  . GPA (number): Grade Point Average of the student.
. Response:
Success: Status 200 with a JSON response: { message: 'Student added successfully.' }
Error: Status 400 with a JSON response: { error: 'Student ID must be unique.' }

2. Get All Students
. Endpoint: GET /allStudents
. Description: Retrieve information about all students in the class.
.Response:
  . Success: HTML response with a list of all students.
  . Error: Status 404 with a JSON response: { error: 'No students found.' }

3. Get Student by ID
. Endpoint: GET /student/:studentID
. Description: Retrieve information about a specific student using their ID.
. Response:
   . Success: HTML response with details of the requested student.
   . Error: Status 404 with a JSON response: { error: 'Student not found.' }

4. Get Class Topper
. Endpoint: GET /topper
. Description: Retrieve information about the student with the highest GPA in the class.
. Response:
  . Success: HTML response with details of the class topper.
  . Error: Status 404 with a JSON response: { error: 'No students found.' }

<--------------Usage--------------->
Adding a Student
To add a new student, send a POST request to /addStudent with the student details in the request body.

Example using cURL:
curl -X POST -H "Content-Type: application/json" -d '{"studentID": "123", "studentName": "John Doe", "GPA": 3.5}' http://localhost:3000/addStudent
Retrieving All Students
To retrieve information about all students, send a GET request to /allStudents.

Example using cURL:
curl http://localhost:3000/allStudents
Retrieving Student by ID
To retrieve information about a specific student by ID, send a GET request to /student/:studentID, replacing :studentID with the actual student ID.

Example using cURL:
curl http://localhost:3000/student/123
Retrieving Class Topper
To retrieve information about the class topper, send a GET request to /topper.

Example using cURL:
curl http://localhost:3000/topper
