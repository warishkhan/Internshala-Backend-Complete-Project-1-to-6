import { useEffect } from 'react';
import './App.css';
import Header from './components/Navbar';
import { BrowserRouter as Router , Routes, Route } from 'react-router-dom';
import AddSales from './pages/AddSales';
import Top5Sales from './pages/Top5Sales';
import TotalRevenue from './pages/TotalRevenue';
import Login from './pages/Login';
import Register from './pages/Register';
import {  useNavigate } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import 'bootstrap/dist/css/bootstrap.min.css';


function App() {

  function DynamicRouting(){
    const dispatch = useDispatch();
    const navigate = useNavigate();

    useEffect(() => {

      const userData = JSON.parse(localStorage.getItem("user"));
      if (userData) {//when user has a login active session
        dispatch({ type: "LOGIN_SUCCESS", payload: userData });
        navigate("/addsales");
      } else {
        localStorage.removeItem("token");
        localStorage.removeItem("user");
        dispatch({ type: "LOGIN_ERROR" });
        navigate("/login");
      }
      // eslint-disable-next-line
    }, []);
    return(
      <Routes>
      <Route exact path = "/addsales" element={<AddSales/>}/>
      <Route exact path = "/top5sales" element={<Top5Sales/>}/>
      <Route exact path = "/revenue" element={<TotalRevenue/>}/>
      <Route exact path = "/login" element={<Login/>}/>
      <Route exact path = "/register" element={<Register/>}/>
     </Routes>
    )
  }

  return (
    <>
     <Router>
     <Header/>
     <DynamicRouting/>
     </Router>
    </>
  );
}

export default App;
