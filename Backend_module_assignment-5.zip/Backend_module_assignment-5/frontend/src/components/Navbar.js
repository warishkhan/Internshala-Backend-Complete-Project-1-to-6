import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import {Link, useLocation  } from 'react-router-dom';
import { useNavigate } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import './Navbar.css'
import Swal from 'sweetalert2'

function Header() {

  const dispatch = useDispatch();
  const navigate = useNavigate();
  const user = JSON.parse(localStorage.getItem('user'))
  const location = useLocation();

// logout 
  const logout = () => {
    try {
      localStorage.removeItem("token");
    localStorage.removeItem("user");
    dispatch({ type: "LOGIN_ERROR" });
    Swal.fire({
      icon: 'success',
      title: 'Logout successfull'
  })
    navigate("/login");
    } catch (error) {
      console.log(error);
      Swal.fire({
        icon: 'error',
        title: 'Some error occurred please try again later!'
    })
    }
  }

  return (
    <Navbar expand="lg" className="bg-primary">
      <Container fluid>
       {user ? (<>
        <Navbar.Brand><Link className='text-white logo' to="/addsales">{user ? user.fullName.toUpperCase()  : "SALES APP"}</Link></Navbar.Brand>
        <Navbar.Toggle/>
        <Navbar.Collapse >
          <Nav>
            <Link className={location.pathname === '/addsales' ? 'text-white nav-link active' : 'text-white nav-link'} to="/addsales">ADD SALES</Link>
            <Link className={location.pathname === '/top5sales' ? 'text-white nav-link active' : 'text-white nav-link'} to="/top5sales">TOP 5 SALES</Link>
            <Link className={location.pathname === '/revenue' ? 'text-white nav-link active' : 'text-white nav-link'} to="/revenue">TODAY'S TOTAL REVENUE</Link>
            <Link className={location.pathname === '/login' ? 'text-white nav-link active' : 'text-white nav-link'} to="/login" onClick={() => logout()}>LOGOUT</Link>
          </Nav>
        </Navbar.Collapse>
        </>
        ):(<>

          <Navbar.Brand><Link className='text-white logo' to="/addsales">{user ? user.fullName : "SALES APP"}</Link></Navbar.Brand>
        <Navbar.Toggle/>
        <Navbar.Collapse >
          <Nav>
            <Link className={location.pathname === '/addsales' ? 'text-white nav-link active' : 'text-white nav-link'} to="/addsales">ADD SALES</Link>
            <Link className={location.pathname === '/top5sales' ? 'text-white nav-link active' : 'text-white nav-link'} to="/top5sales">TOP 5 SALES</Link>
            <Link className={location.pathname === '/revenue' ? 'text-white nav-link active' : 'text-white nav-link'} to="/revenue">TODAY'S TOTAL REVENUE</Link>
            <Link className={location.pathname === '/login' ? 'text-white nav-link active' : 'text-white nav-link'} to="/login">LOGIN</Link>
            <Link className={location.pathname === '/register' ? 'text-white nav-link active' : 'text-white nav-link'} to="/register">REGISTER</Link>
          </Nav>
        </Navbar.Collapse>
        </>)}
      </Container>
    </Navbar> 
  );
}

export default Header;