import React, { useState } from 'react';
import axios from 'axios';
import Form from 'react-bootstrap/Form';
import { useNavigate } from 'react-router-dom';
import Swal from 'sweetalert2'

function Register() {
  const navigate = useNavigate();
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [registrationSuccess, setRegistrationSuccess] = useState(false);

  // handle register
  const handleRegister = async (e) => {
    e.preventDefault();
    try {
      await axios.post('http://localhost:5000/api/register', { firstName, lastName, email, password });
      Swal.fire({
        icon: 'success',
        title: 'User successfully registered'
    })
      setRegistrationSuccess(true);
      setFirstName("")
      setLastName("")
      setEmail("")
      setPassword("")
    } catch (error) {
      Swal.fire({
        icon: 'error',
        title: 'Some error occurred please try again later!'
    })
    }
  };

  if (registrationSuccess) {
    navigate('/login');
  }

  return (
    <Form className='container' onSubmit={handleRegister}>
    <h1 className='text-center mt-3'>REGISTRATION FORM</h1>
      <Form.Group className="mb-3">
        <Form.Label>First Name</Form.Label>
        <Form.Control type="text" value={firstName} onChange={(e) => setFirstName(e.target.value)} required/>
      </Form.Group>
      <Form.Group className="mb-3">
        <Form.Label>Last Name</Form.Label>
        <Form.Control type="text" value={lastName} onChange={(e) => setLastName(e.target.value)} required />
      </Form.Group>
      <Form.Group className="mb-3">
        <Form.Label>Email</Form.Label>
        <Form.Control type="email" value={email} onChange={(e) => setEmail(e.target.value)} required/>
      </Form.Group>
      <Form.Group className="mb-3">
        <Form.Label>password</Form.Label>
        <Form.Control type="password" value={password} onChange={(e) => setPassword(e.target.value)} required/>
      </Form.Group>
      <button className='btn btn-primary w-100' type='submit'>Register</button>
    </Form>
  );
}

export default Register;