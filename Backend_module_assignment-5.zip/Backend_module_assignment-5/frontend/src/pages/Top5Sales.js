import React, { useEffect, useState } from 'react';
import axios from 'axios';
import Table from 'react-bootstrap/Table';
import { API_BASE_URL } from '../../src/config'
import Swal from 'sweetalert2'
import { useNavigate } from 'react-router-dom';
import './top5Sales.css'

function Top5Sales() {
  const [top5Sales, setTop5Sales] = useState([]);
  const navigate = useNavigate();

  const CONFIG_OBJ = {
    headers: {
        "Content-Type": "application/json",
        "Authorization": "Bearer " + localStorage.getItem("token")
    }
}

  useEffect(() => {
    const fetchTop5Sales = async () => {
      try {
        // Implement top 5 sales logic using axios.get('/api/top-5-sales');
        const response = await axios.get(`${API_BASE_URL}/api/top-5-sales`, CONFIG_OBJ);
        setTop5Sales(response.data);
      } catch (error) {
        Swal.fire({
          icon: 'error',
          title: 'Please login'
      });
      navigate('/login');
      }
    };

    fetchTop5Sales();
    // eslint-disable-next-line
  }, [navigate]);
  return (
    <div className="container">
    <h1 className='text-center my-5'>TOP 5 SALES</h1>
    <Table striped bordered hover className='container table-container'>
      <thead>
        <tr>
          <th>#</th>
          <th>Sales Id:</th>
          <th>Product Name</th>
          <th>Quantity</th>
          <th>Sale Amount</th>
        </tr>
      </thead>
      <tbody> 
        {top5Sales.map((sale,index) => (
          <tr key={sale._id}>
          <td >{index + 1}</td>
          <td >{sale._id.substring(0,6)}</td>
          <td >{sale.productName.charAt(0).toUpperCase() + sale.productName.slice(1)}</td>
          <td >{sale.quantity}</td>
          <td >{sale.amount}</td>
          </tr>
        ))}
       
      </tbody>
    </Table>
    </div>
  );
}

export default Top5Sales;