import React, { useEffect, useState } from 'react';
import axios from 'axios';
import Form from 'react-bootstrap/Form';
import { API_BASE_URL } from '../../src/config'
import Swal from 'sweetalert2';
import { useNavigate } from 'react-router-dom';

function AddSales() {
  const [productName, setProductName] = useState('');
  const [quantity, setQuantity] = useState('');
  const [amount, setAmount] = useState('');
  const navigate = useNavigate();
// Getting token from localStorage
  const CONFIG_OBJ = {
    headers: {
        "Content-Type": "application/json",
        "Authorization": "Bearer " + localStorage.getItem("token")
    }
}
// handle add sales
  const handleAddSales = async (e) => {
    e.preventDefault()
    try {
      // Implement adding new sales entry logic using axios.post('/api/add-sales', { product, amount });
      await axios.post(`${API_BASE_URL}/api/add-sales`, { productName, quantity,amount },CONFIG_OBJ);
      Swal.fire({
        icon: 'success',
        title: 'Product added Successfully'
    })
    setProductName('');
    setQuantity('');
    setAmount('')
    } catch (error) {
      console.log(error);
    }
  };

  useEffect(()=>{
    if(localStorage.getItem("token")){
  
    }else{
      Swal.fire({
        icon: 'error',
        title: 'Please login'
    })
      navigate('/login')
    }
   },[navigate])

  return (
    <Form className='container' onSubmit={(e)=>handleAddSales(e)}>
    <h1 className='text-center mt-3'>ADD SALE ENTRY</h1>
      <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
        <Form.Label>Product Name</Form.Label>
        <Form.Control type="text" value={productName} onChange={(e) => setProductName(e.target.value)}/>
      </Form.Group>
      <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
        <Form.Label>Quantiy</Form.Label>
        <Form.Control type="number" value={quantity} onChange={(e) => setQuantity(e.target.value)}/>
      </Form.Group>
      <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
        <Form.Label>Amount</Form.Label>
        <Form.Control type="number" value={amount} onChange={(e) => setAmount(e.target.value)}/>
      </Form.Group>
      <button className='btn btn-primary w-100' type='submit'>Add Sales</button>
    </Form>
  );
}

export default AddSales;