import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { API_BASE_URL } from '../config';
import Swal from 'sweetalert2'
import { useNavigate } from 'react-router-dom';

const TotalRevenue = () => {
  const [totalRevenue, setTotalRevenue] = useState(0);
  const navigate = useNavigate();

  // Getting token from localStorage
  const CONFIG_OBJ = {
    headers: {
        "Content-Type": "application/json",
        "Authorization": "Bearer " + localStorage.getItem("token")
    }
}
  useEffect(() => {
    const fetchTotalRevenue = async () => {
      try {
        // Implement total revenue logic using axios.get('/api/total-revenue');
        const response = await axios.get(`${API_BASE_URL}/api/total-revenue`, CONFIG_OBJ);
        setTotalRevenue(response.data.totalRevenue);
      } catch (error) {
        // console.error('Error fetching total revenue:', error);
        Swal.fire({
          icon: 'error',
          title: 'Please login'
      });
      navigate('/login');
      
        
      }
    };
    fetchTotalRevenue();
    // eslint-disable-next-line
  }, []);

  
  return (
    <>
    <h1 className='text-center my-5'>TODAY's REVENUE IS {totalRevenue}</h1>
    </>
  )
}

export default TotalRevenue