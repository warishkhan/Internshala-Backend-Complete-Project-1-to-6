********************************************* Summery of my project *********************************************************************

batch :- 1st November 2023

Name :- Warish khan

Assignment_5_Putting it all together: Creating a Web App- Part 2

I have created this Sales Dashboard website using React, Node.js with Express and Mongoose .The Sales dashboard website is a simple web application that allows users to add products To Database using post api and Get products Data Using get api. It is designed with a user-friendly interface.The backend of the project is developed using Node.js with Express and Mongoose. It provides RESTful API endpoints for user registration, login, sales entry, and related functionalities.

==================================IMPORTANT NOTES======================================
PLEASE INSTALL node_modules FOR BOTH THE FRONTEND AND BACKEND!
For frontend run cammand: 'cd frontend' then 'npm install'
for start the application : 'npm start'

For backend run cammand: 'cd backend' then 'npm install'
For start the server : 'node server.js'

***********API Endpoints*************
User Registration
Endpoint: /api/register
Method: POST
Description: Registers a new user.

<----------Login----------->
Endpoint: /api/login
Method: POST
Description: Logs in an existing user.

<------------Adding New Sales Entry------------->
Endpoint: /api/sales
Method: POST
Description: Adds a new sales entry.

<-----------Top 5 Sales for Today--------------->
Endpoint: /api/sales/top
Method: GET
Description: Retrieves the top 5 sales entries for today.

<----------Total Revenue--------------->
Endpoint: /api/revenue
Method: GET
Description: Retrieves the total revenue.

<============Packages================>
Express: Fast, unopinionated, minimalist web framework for Node.js.
Mongoose: Elegant MongoDB object modeling for Node.js.
Cors: Connectin frontend to backend.
Body-parser: Converting Json to javaScript Object.
Bcrypt: For Encrypting password.
Jsonwebtoken: for private and protected routes.

<*********************Frontend******************>
=============Overview===============
The frontend of the project consists of various pages and components developed using React. It integrates with the backend API endpoints for user interaction and data management.

<---------------Pages------------------>
Login Page
Description: Page for user login.

Registration Page
Description: Page for user registration.

Sales Entry Page
Description: Page for adding new sales entries.

Dashboard Page
Description: Page for displaying user dashboard with sales data.

total revenue page
Description: page for displaying today's revenue.


<-------------Components------------->
Navbar
Description: Component for displaying navigation bar.

<---------------Packages---------------->
React: JavaScript library for building user interfaces.
React Router DOM: Declarative routing for React applications.
Axios: Promise-based HTTP client for the browser and Node.js.
React Bootstrap: for styling components.
Redux: For state management.

