const express = require('express');
const { registerRoutes, loginRoutes, addsales, top5Sales, totalRevenue, } = require('../controllers/controller');
const router = express.Router();
const auth = require('../middileware/protectedResources');

// User Registration API
router.post('/api/register', registerRoutes);
  
  // Login API
  router.post('/api/login', loginRoutes);
  
  // Adding new sales entry API
  router.post('/api/add-sales',auth, addsales);
  
  // Top 5 sales for today API
  router.get('/api/top-5-sales',auth, top5Sales);
  
  
  // Total revenue API
  router.get('/api/total-revenue',auth,totalRevenue);

module.exports = router;