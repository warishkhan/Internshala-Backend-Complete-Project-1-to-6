const mongoose = require('mongoose');

// Connect to MongoDB (replace 'your_database_url' with your actual MongoDB connection string)
mongoose.connect('mongodb://localhost:27017/salesdb3').then(()=>{
    console.log("database connected");
}).catch(()=>{
    console.log('not coonected');
});