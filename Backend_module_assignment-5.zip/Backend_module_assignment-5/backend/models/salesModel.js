const mongoose = require('mongoose');
const { ObjectId } = mongoose.Schema.Types;

const salesEntrySchema = new mongoose.Schema({
    productName: { type: String, required: true },
    quantity: { type: Number, required: true },
    amount: { type: Number, required: true },
    author: {
      type: ObjectId,
      ref: "User"
  },
    date: { type: Date, default: Date.now },
  });


const SalesEntry = mongoose.model('SalesEntry', salesEntrySchema);

module.exports = SalesEntry;