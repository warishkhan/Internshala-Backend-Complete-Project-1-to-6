module.exports = {
    // MONGOBD_URL: "mongodb://127.0.0.1:27017/reactogram",
    JWT_SECRET: "hafsfffgg72846285jjjkh54646467hh"
}