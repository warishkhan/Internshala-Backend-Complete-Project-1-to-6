const bcrypt = require('bcrypt');
const { JWT_SECRET } = require('../config');
const jwt = require("jsonwebtoken");

// models
const User = require('../models/userModel');
const SalesEntry = require('../models/salesModel');

const registerRoutes = async (req, res) => {
    try {
      const { firstName, lastName, email, password } = req.body;
      
      // Check if the username already exists
      const existingUser = await User.findOne({ email });
      if (existingUser) {
        return res.status(400).json({ error: 'Username already exists' });
      }
    // Hashing password
      const hash = await bcrypt.hash(password,10);
  
      const user = new User({ firstName, lastName, email, password:hash });
      await user.save();
      res.status(201).json({ message: 'User registered successfully' });
    } catch (error) {
      console.error('Error during registration:', error);
      res.status(500).json({ error: 'Internal Server Error' });
    }
  };

  const loginRoutes = async (req, res) => {
    try {
      const { email, password } = req.body;
  
      // Check if the user exists
      const user = await User.findOne({ email });
      if (!user) {
        return res.status(401).json({ error: 'Invalid username or password' });
      }
      // comparing passwords
      const match = await bcrypt.compare(password, user.password);
      // Check if the password is correct
      if (!match) {
        return res.status(401).json({ error: 'Invalid username or password' });
      }

      const jwtToken = jwt.sign({ _id: user._id }, JWT_SECRET);
      const userInfo = { "_id": user._id, "email": user.email, "fullName": user.firstName + " " + user.lastName };
      res.status(200).json({ result: { token: jwtToken, user: userInfo } });
  
      // res.status(200).json({ message: 'Login successful' });
    } catch (error) {
      console.error('Error during login:', error);
      res.status(500).json({ error: 'Internal Server Error' });
    }
  };

  const addsales = async (req, res) => {
    try {
      const { productName, quantity, amount } = req.body;
      req.user.password = undefined;
      const salesEntry = new SalesEntry({
        productName,
        quantity,
        amount,
        author: req.user
      });
    const post =  await salesEntry.save();
      // res.status(201).json({ message: 'Sales entry added successfully' });
      res.status(201).json({ post: post });
    } catch (error) {
      console.error('Error during adding sales entry:', error);
      res.status(500).json({ error: 'Internal Server Error' });
    }
  };

  const top5Sales = async (req, res) => {
    try {
      // Fetch the top 5 sales entries for today (date comparison may need adjustment)
      // const top5Sales = await SalesEntry.find({ date: { $gte: new Date().setHours(0, 0, 0, 0) } })
      const top5Sales = await SalesEntry.find({ author: req.user._id })
        .sort({ amount: -1 })
        .limit(5);
  
      res.status(200).json(top5Sales);
    } catch (error) {
      console.error('Error fetching top 5 sales:', error);
      res.status(500).json({ error: 'Internal Server Error' });
    }
  };

// Total revenue API for today
const totalRevenue = async (req, res) => {
  try {
    // Get the current date
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    // Get the logged-in user's ID from the request (you need to implement authentication middleware)
    // const author = req.user._id; // Assuming the user ID is available in the request

    // Calculate the total revenue for today for the logged-in user
    const totalRevenue = await SalesEntry.aggregate([
      { $match: { author: req.user._id, date: { $gte: today } } }, // Filter sales entries for today by user
      { $group: { _id: null, totalRevenue: { $sum: '$amount' } } },
    ]);

    res.status(200).json({ totalRevenue: totalRevenue.length ? totalRevenue[0].totalRevenue : 0 });
  } catch (error) {
    console.error('Error fetching total revenue:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};

  module.exports = {registerRoutes, loginRoutes, addsales, top5Sales, totalRevenue}