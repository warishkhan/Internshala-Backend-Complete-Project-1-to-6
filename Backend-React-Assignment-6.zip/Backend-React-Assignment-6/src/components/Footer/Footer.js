import React from 'react'
import { Link } from 'react-router-dom'

const Footer = () => {
  return (
    <>
       <div className="container-fluid bg-dark">
        <div className="container d-flex justify-content-center align-items-center flex-column">
            <div className="row border-bottom border-secondary w-100 my-3 pb-4">
                <div className="col-xs-12 col-sm-12 col-md-6 col-lg-3 d-flex justify-content-center align-items-center">
                    <ul className="nav flex-column">
                        <li className="nav-item">
                          <Link className="nav-link text-white fs-3 text-center" aria-current="page" href="#">Women</Link>
                        </li>
                        <li className="nav-item">
                          <Link className="nav-link text-white text-center" href="#">Dresses</Link>
                        </li>
                        <li className="nav-item">
                          <Link className="nav-link text-white text-center" href="#">Pants</Link>
                        </li>
                        <li className="nav-item">
                          <Link className="nav-link text-white text-center" href="#">Skirts</Link>
                        </li>                        
                      </ul>
                </div>
                <div className="col-xs-12 col-sm-12 col-md-6 col-lg-3 d-flex justify-content-center align-items-center">
                    <ul className="nav flex-column">
                        <li className="nav-item">
                          <Link className="nav-link text-white fs-3 text-center" aria-current="page" href="#">Men</Link>
                        </li>
                        <li className="nav-item">
                          <Link className="nav-link text-white text-center" href="#">Shirts</Link>
                        </li>
                        <li className="nav-item">
                          <Link className="nav-link text-white text-center" href="">Pants</Link>
                        </li>
                        <li className="nav-item">
                          <Link className="nav-link text-white text-center" href="#">Hoodies</Link>
                        </li>                        
                      </ul>
                </div>
                <div className="col-xs-12 col-sm-12 col-md-6 col-lg-3 d-flex justify-content-center">
                    <ul className="nav flex-column">
                        <li className="nav-item">
                          <Link className="nav-link text-white fs-3 text-center" aria-current="page" href="#">Kids</Link>
                        </li>                      
                      </ul>
                </div>
                <div className="col-xs-12 col-sm-12 col-md-6 col-lg-3 d-flex justify-content-center align-items-center">
                    <ul className="nav flex-column">
                        <li className="nav-item">
                          <Link className="nav-link text-white fs-3 text-center" aria-current="page" href="#">Links</Link>
                        </li>
                        <li className="nav-item">
                          <Link className="nav-link text-white text-center" href="#">Home</Link>
                        </li>
                        <li className="nav-item">
                          <Link className="nav-link text-white text-center" href="#">Login</Link>
                        </li>
                        <li className="nav-item">
                          <Link className="nav-link text-white text-center" href="#">Contact</Link>
                        </li>                        
                      </ul>
                </div>
            </div>
            <p className="text-white text-center">Copyright &copy;WarTech-Shopping 2023-24</p>
        </div>
    </div>
    </>
  )
}

export default Footer