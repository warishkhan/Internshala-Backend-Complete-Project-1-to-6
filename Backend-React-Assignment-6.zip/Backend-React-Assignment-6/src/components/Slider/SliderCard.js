import React from "react";
import { Link } from "react-router-dom";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faCartShopping } from "@fortawesome/free-solid-svg-icons";

const SliderCard = ({ elem }) => {
  return (
    <>
      <div className="card m-2" style={{ width: "18rem" }}>
        <img
          src={elem.image}
          className="card-img-top"
          alt="kids"
          style={{ height: "15rem" }}
        />
        <div className="card-body  d-flex justify-content-center align-items-center flex-column">
          <h5 className="card-title">{elem.name}</h5>
          <h5 className="card-title">{elem.price}</h5>
          <p className="card-text text-center">{elem.description}</p>
          <Link href="#" className="btn">
            <FontAwesomeIcon
              className="cart fa fa-shopping-cart cart-btn"
              icon={faCartShopping}
            />
            <span className="btn-text fw-bold">Add To Cart</span>
          </Link>
        </div>
      </div>
    </>
  );
};

export default SliderCard;
