export const data =[
    {
        name:"Outfit",
        price:"$15",
        description:"Some quick example text to build on the card title and make up the bulk of the card's content.",
        image:"https://images.unsplash.com/photo-1578897367107-2828e351c8a8?q=80&w=1964&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"
    },
    {
        name:"Outfit",
        price:"$15",
        description:"Some quick example text to build on the card title and make up the bulk of the card's content.",
        image:"https://plus.unsplash.com/premium_photo-1683121263622-664434494177?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTN8fHNob3BwaW5nJTIwbWFsbHxlbnwwfHwwfHx8MA%3D%3D"
    },
    {
        name:"Outfit",
        price:"$15",
        description:"Some quick example text to build on the card title and make up the bulk of the card's content.",
        image:"https://images.unsplash.com/photo-1513094735237-8f2714d57c13?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTl8fHNob3BwaW5nJTIwbWFsbHxlbnwwfHwwfHx8MA%3D%3D"
    },
    {
        name:"Outfit",
        price:"$15",
        description:"Some quick example text to build on the card title and make up the bulk of the card's content.",
        image:"https://images.unsplash.com/photo-1492707892479-7bc8d5a4ee93?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTh8fHNob3BwaW5nfGVufDB8fDB8fHww"
    },
    {
        name:"Outfit",
        price:"$15",
        description:"Some quick example text to build on the card title and make up the bulk of the card's content.",
        image:"https://plus.unsplash.com/premium_photo-1664201889947-ca672c9d4134?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTd8fHNob3BwaW5nfGVufDB8fDB8fHww"
    },
]