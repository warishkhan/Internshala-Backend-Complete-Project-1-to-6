import React from 'react'
import logo from '../../images/WarTech.png'
import { Link, NavLink } from 'react-router-dom'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'; 
import { faCartShopping } from '@fortawesome/free-solid-svg-icons'

const Header = () => {
  return (
    <>
    <nav className="navbar navbar-expand-lg bg-dark">
    <div className="container-fluid">
      
      <NavLink className="navbar-brand" href="index.html"><img src={logo} alt="WarTech-logo" className="img-fluid"/></NavLink>
      <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span className="navbar-toggler-icon"></span>
      </button>
      <div className="collapse navbar-collapse" id="navbarSupportedContent">
        <form className="d-flex mt-2" role="search">
          <input className="form-control me-2" type="search" placeholder="Search" aria-label="Search"/>
          <input type="button" value="Search" />
        </form>
        <ul className="navbar-nav me-auto mb-2 mb-lg-0 mt-1">
            <li className="nav-item btn-top"><NavLink href="#" className="text-decoration-none text-dark fw-bold p-2 btns">Login</NavLink></li>
            <li className="nav-item mt-1"> 
              <NavLink className="nav-link text-white" href="#"> 
                 <FontAwesomeIcon className="cart-custom cart fa fa-shopping-cart" icon={faCartShopping} />
              </NavLink> 
           </li>
        </ul>
      </div>
    </div>
  </nav>

  <nav className="container-fluid bg-light">
        <ul className="nav nav-pills d-flex justify-content-center align-items-center fw-bold">
          <li className="nav-item">
            <NavLink className="nav-link text-dark bg-light" href="#">Home</NavLink>
          </li>
          <li className="nav-item">
            <NavLink className="nav-link text-dark bg-light" href="#">All Products</NavLink>
          </li>
          <li className="nav-item dropdown">
            <Link className="nav-link dropdown-toggle text-dark" data-bs-toggle="dropdown" href="#" role="button" aria-expanded="false">Women</Link>
            <ul className="dropdown-menu">
              <li><NavLink className="dropdown-item bg-light text-dark" href="#">All products</NavLink></li>
              <li><NavLink className="dropdown-item bg-light text-dark" href="#">Dresses</NavLink></li>
              <li><NavLink className="dropdown-item bg-light text-dark" href="#">Pants</NavLink></li>
              <li><NavLink className="dropdown-item bg-light text-dark" href="#">Skirts</NavLink></li>
            </ul>
          </li>
          <li className="nav-item dropdown">
            <Link className="nav-link dropdown-toggle text-dark" data-bs-toggle="dropdown" href="#" role="button" aria-expanded="false">Men</Link>
            <ul className="dropdown-menu">
              <li><NavLink className="dropdown-item bg-light text-dark" href="#">All products</NavLink></li>
              <li><NavLink className="dropdown-item bg-light text-dark" href="#">Shirts</NavLink></li>
              <li><NavLink className="dropdown-item bg-light text-dark" href="#">Pants</NavLink></li>
              <li><NavLink className="dropdown-item bg-light text-dark" href="#">Hoodies</NavLink></li>
            </ul>
          </li>
          <li className="nav-item">
            <NavLink className="nav-link text-dark bg-light" href="#">Kids</NavLink>
          </li>
          <li className="nav-item">
            <NavLink className="nav-link text-dark bg-light" href="#">Contact</NavLink>
          </li>
        </ul>
      </nav>
      </>
  )
}

export default Header