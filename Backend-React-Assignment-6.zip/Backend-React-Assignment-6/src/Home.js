import React from 'react'
import HomeCover from './components/HomeCover/HomeCover'
import Slider from './components/Slider/Slider'

const Home = () => {
  return (
    <>
        <HomeCover/>
        <Slider/>
    </>
  )
}

export default Home