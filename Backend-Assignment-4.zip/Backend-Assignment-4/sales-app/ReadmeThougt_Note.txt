********************************************* Summery of my project *********************************************************************

batch :- 1st November 2023

Name :- Warish khan

Assignment_4_Putting it all together: Creating a Web App- Part 1

I have created this Sales Dashboard website using React.The Sales dashboard website is a simple web application that allows users to add products To Database using post api and Get products Data Using get api. It is designed with a user-friendly interface.This documentation provides an overview of the Sales dashboard. This document provides documentation for the frontend components, pages, and packages used in the Sales dashboard module assignment.

********************Pages**********************
<--------------Login Page---------------->
Description: Page for user login.
Components:
LoginForm: Component for displaying login form fields.
SubmitButton: Component for submitting the login form.
Packages:
React Router DOM: Used for page navigation.

<-------------------Registration Page---------------->
Description: Page for user registration.
Components:
RegistrationForm: Component for displaying registration form fields.
SubmitButton: Component for submitting the registration form.
Packages:
React Router DOM: Used for page navigation.

<-------------Sales Entry Page-------------------->
Description: Page for adding new sales entries.
Components:
SalesEntryForm: Component for displaying sales entry form fields.
SubmitButton: Component for submitting the sales entry form.

<-------------------Dashboard Page----------------->
Description: Page for displaying user dashboard with sales data.
Components:
SalesList: Component for displaying list of sales entries.
TotalRevenue: Component for displaying total revenue.

<------------Components--------------->
Navbar
Description: Component for displaying header.
Packages:
Bootstrap: Used for form management and styling.

<----------------Packages------------->
React Router DOM
Description: Declarative routing for React applications.
Installation:
npm install react-router-dom

Bootstrap
Description: css library.
Installation:
npm install bootstrap react-bootstrap
