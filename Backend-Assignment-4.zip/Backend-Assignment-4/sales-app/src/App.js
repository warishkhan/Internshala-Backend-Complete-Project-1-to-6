import React from 'react'
import './App.css';
import Header from './components/Navbar';
import { BrowserRouter as Router , Routes, Route } from 'react-router-dom';
import AddSales from './pages/AddSales';
import Top5Sales from './pages/Top5Sales';
import TotalRevenue from './pages/TotalRevenue';
import Login from './pages/Login';
import Register from './pages/Register';

// React Router Dom is used to build single-page applications i.e. applications that have many pages or components but the page is never refreshed instead the content is dynamically fetched based on the URL.
function App() {
  // routes For navigation
  return (
    <>
     <Router>
     <Header/>
     <Routes>
      <Route exact path = "/" element={<AddSales/>}/>
      <Route exact path = "/top5sales" element={<Top5Sales/>}/>
      <Route exact path = "/totalrevenue" element={<TotalRevenue/>}/>
      <Route exact path = "/login" element={<Login/>}/>
      <Route exact path = "/register" element={<Register/>}/>
     </Routes>
     </Router>
    </>
  );
}

export default App;
