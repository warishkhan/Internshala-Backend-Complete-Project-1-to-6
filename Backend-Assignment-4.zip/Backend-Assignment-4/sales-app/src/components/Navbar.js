import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import {Link  } from 'react-router-dom';

// React Router Dom is used to build single-page applications i.e. applications that have many pages or components but the page is never refreshed instead the content is dynamically fetched based on the URL.
function Header() {
  return (
    <Navbar expand="lg" className="bg-primary">
      <Container fluid>
        <Navbar.Brand><Link className='text-white nav-link' to="/">SALES APP</Link></Navbar.Brand>
        <Navbar.Toggle/>
        <Navbar.Collapse >
          <Nav>
            <Link className='text-white nav-link' to="/">ADD SALES</Link>
            <Link className='text-white nav-link' to="/top5sales">TOP 5 SALES</Link>
            <Link className='text-white nav-link' to="/totalrevenue">TODAY'S TOTAL REVENUE</Link>
            <Link className='text-white nav-link' to="/login">LOGIN</Link>
            <Link className='text-white nav-link' to="/register">REGISTER</Link>
            <Link className='text-white nav-link' to="/login">LOGOUT</Link>
          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar> 
  );
}

export default Header;