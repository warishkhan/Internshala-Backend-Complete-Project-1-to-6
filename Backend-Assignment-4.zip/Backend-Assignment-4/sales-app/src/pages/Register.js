import Form from 'react-bootstrap/Form';
// React-Bootstrap takes the CSS framework of Bootstrap and replaces any existing JavaScript with strictly React components.
function Register() {
  // Register form
  return (
    <Form className='container'>
    <h1 className='text-center mt-3'>REGISTRATION FORM</h1>
      <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
        <Form.Label>First Name</Form.Label>
        <Form.Control type="text" required/>
      </Form.Group>
      <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
        <Form.Label>Last Name</Form.Label>
        <Form.Control type="text" required />
      </Form.Group>
      <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
        <Form.Label>Email</Form.Label>
        <Form.Control type="email" />
      </Form.Group>
      <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
        <Form.Label>password</Form.Label>
        <Form.Control type="password" />
      </Form.Group>
      <button className='btn btn-primary w-100'>Submit</button>
    </Form>
  );
}

export default Register;