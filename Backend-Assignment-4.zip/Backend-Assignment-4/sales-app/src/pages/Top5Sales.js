// React-Bootstrap takes the CSS framework of Bootstrap and replaces any existing JavaScript with strictly React components.
import Table from 'react-bootstrap/Table';

function Top5Sales() {
  // Top 5 table
  return (
    <div className="container">
    <h1 className='text-center my-5'>TOP 5 SALES</h1>
    <Table striped bordered hover className='container'>
      <thead>
        <tr>
          <th>#</th>
          <th>Sales Id:</th>
          <th>Product Name</th>
          <th>Quantity</th>
          <th>Sale Amount</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>1</td>
          <td>S1212</td>
          <td>Laptop</td>
          <td>5</td>
          <td>90000</td>
        </tr>
        <tr>
          <td>2</td>
          <td>S1412</td>
          <td>Mobile</td>
          <td>5</td>
          <td>85000</td>
        </tr>
        <tr>
          <td>3</td>
          <td>S1512</td>
          <td>Computer</td>
          <td>4</td>
          <td>100000</td>
        </tr>
      </tbody>
    </Table>
    </div>
  );
}

export default Top5Sales;