import React from 'react'

const TotalRevenue = () => {
  return (
    <h1 className='text-center my-5'>TODAY's REVENUE IS 175000</h1>
  )
}

export default TotalRevenue