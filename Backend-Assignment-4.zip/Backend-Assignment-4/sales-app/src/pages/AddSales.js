import Form from 'react-bootstrap/Form';

function AddSales() {
  return (
    <Form className='container'>
    <h1 className='text-center mt-3'>ADD SALE ENTRY</h1>
      <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
        <Form.Label>Product Name</Form.Label>
        <Form.Control type="text" />
      </Form.Group>
      <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
        <Form.Label>Quantiy</Form.Label>
        <Form.Control type="number" />
      </Form.Group>
      <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
        <Form.Label>Amount</Form.Label>
        <Form.Control type="number" />
      </Form.Group>
      <button className='btn btn-primary w-100'>Submit</button>
    </Form>
  );
}

export default AddSales;