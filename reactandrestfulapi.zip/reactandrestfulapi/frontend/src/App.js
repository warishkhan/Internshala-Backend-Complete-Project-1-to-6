import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './App.css'

function App() {
  const [task, setTask] = useState('');
  const [tasks, setTasks] = useState([]);
  // const [color, setColor] = useState('');

  useEffect(() => {
    // Fetch tasks from backend on component mount
    fetchTasks();
  }, []);

  const fetchTasks = async () => {
    try {
      const response = await axios.get('http://localhost:3001/getTasks');
      setTasks(response.data.tasks || []);
    } catch (error) {
      console.error('Error fetching tasks', error);
    }
  };

  const addTask = async () => {
    if (task.trim() === '') {
      // Do not add empty tasks
      alert("Please add task!...")
      return;
    }
    try {
      await axios.post('http://localhost:3001/addTask', { task });
      // Fetch updated tasks after adding a new task
      fetchTasks();
      setTask('');
    } catch (error) {
      console.error('Error adding task', error);
    }
  };

  return (
    <div className='container d-flex justify-content-center align-items-center flex-column'>
    <h1 className='text-center my-5'>To Do List App</h1>
    <div className="d-flex justify-content-center align-items-center w-100 flex-column flex-sm-column flex-md-row flex-lg-row">
    <button className='btn w-100'>Enter the Task</button>
      <input className='form-control m-2' placeholder='Get groceries' id='colorValue' type="text" value={task} onChange={(e) => setTask(e.target.value)} />
      <button className='btn w-100' onClick={addTask}>Add Task</button>
    </div>
      <ul className='d-flex justify-content-center align-items-center w-100 mt-3 flex-column'>
        {tasks.map((t, index) => (
          <li className='list m-2 fs-4' key={index}>{t}</li>
        ))}
      </ul>
    </div>
  );
}

export default App;
