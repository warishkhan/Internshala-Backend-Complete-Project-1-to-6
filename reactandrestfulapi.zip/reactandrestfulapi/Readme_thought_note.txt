********************************************* Summery of my project *********************************************************************

batch :- 1st November 2023

Name :- Warish khan

Assignment_2_Internshala-React_&_RESTFUL_API

I have created this Todo List App website using React, Node, Express and RESTful Api's.The Todo App website is a simple web application that allows users to add Task using post api and Get tasks Data Using get api. It is designed with a user-friendly interface.This documentation provides an overview of the Todo List App, which allows users to perform Add Task and Its Remove tasks automatically when Restart the server. The API is built using React,RESTful api, Node.js and Express, and it utilizes the node-persist library for persistent storage.

>>>>>>>>>>>>>>>>>>>>>>>>>>>>IMPORTANT NOTES<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
Please Add node_modules in both the Frontend And Backend folder.
To add node_modules Please run  ****npm install**** command in vs code terminal.

*************************************************Project Structure***************************************************** 

The To-Do list application consists of two main components: the backend, implemented in Node.js with Express, and the frontend, built with React. The project structure is organized as follows:

/todo-app
  /backend
    - server.js
    - package.json
  /frontend
    /src
      - App.js
      - index.js
    /public
      - index.html
    - package.json
  - package.json

. /backend: Contains the server-side code for handling requests, storing tasks using Node-persist.

. server.js: The main server file.
. package.json: Configuration file for backend dependencies.
. /frontend: Includes the client-side code built with React.

. /src: Contains React components.
. App.js: The main component responsible for rendering the To-Do list.
. index.js: Entry point for rendering the React application.
. /public: Static files, including the HTML file.
. index.html: The HTML file that hosts the React application.
. package.json: Configuration file for frontend dependencies.

<-------------Backend Setup------------------->
1. Navigate to the /backend folder in the terminal.

2. Run the following commands to initialize the backend and install necessary dependencies:

npm init -y
npm install express node-persist cors

3. Start the backend server:
node server.js
The server will run on http://localhost:5000.

<-----------Frontend Setup.------------>
1. Navigate to the /frontend folder in the terminal.

2. Run the following commands to initialize the frontend and install necessary dependencies:
npm init -y
npm install react react-dom

3. Start the React development server:
npm start
The React application will be accessible at http://localhost:3000

<--------------Usage---------------->
1. Open your web browser and go to http://localhost:3000.

2. Enter a task in the input box and click "Add Task" to add it to the To-Do list.

3. The added tasks will be displayed below the input box.

4. To clear the tasks and storage, click the "Clear Tasks" button. This action will remove all tasks stored in Node-persist.

Notes
The application uses Node-persist for local storage. On restarting the application, the stored tasks will clear.

The backend server runs on http://localhost:3001, and the frontend development server runs on http://localhost:3000.


