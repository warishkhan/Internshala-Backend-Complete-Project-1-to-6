const express = require('express');
const Storage = require('node-persist');
const cors = require('cors')

const app = express();
const port = 3001;

app.use(express.json());
app.use(cors());

// Initialize NodePersist asynchronously
const initializeNodePersist = async () => {
  await Storage.init();
  // Clear data on application restart
  await Storage.clear();
};

initializeNodePersist().then(() => {
  app.post('/addTask', async (req, res) => {
    try {
      const task = req.body.task;

      // Save task to Node-persist storage
      const tasks = await Storage.getItem('tasks') || [];
      tasks.push(task);
      await Storage.setItem('tasks', tasks);

      res.status(200).send('Task added successfully');
    } catch (error) {
      console.error('Error adding task', error);
      res.status(500).send('Internal Server Error');
    }
  });

  app.get('/getTasks', async (req, res) => {
    try {
      // Retrieve tasks from Node-persist storage
      const tasks = await Storage.getItem('tasks') || [];
      res.status(200).json({ tasks });
    } catch (error) {
      console.error('Error fetching tasks', error);
      res.status(500).send('Internal Server Error');
    }
  });

  app.listen(port, () => {
    console.log(`Backend server is running at http://localhost:${port}`);
  });
});
