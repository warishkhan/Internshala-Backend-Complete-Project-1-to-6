********************************************* Summery of my project *********************************************************************

batch :- 1st November 2023

Name :- Warish khan

Assignment_3_Internshala-MONGODB_AND_MYSQL

I have created this Todo List App website using React,MySql, Node, Express and RESTful Api's.The Todo App website is a simple web application that allows users to add Task using post api and Get tasks Data Using get api. It is designed with a user-friendly interface.This documentation provides an overview of the Todo List App, which allows users to perform Add Task and Its Remove tasks from the Database. The API is built using React,MySql,RESTful api, Node.js and Express, and it utilizes the MYSQl library for storage.

****************IMPORTANT NOTES!****************** 
Please Add node_modules in both the backend and frontend. Run the npm install command before start the application and also start xampp server to cannect mysql database.
  

*************************************************Project Structure***************************************************** 

The ToDo List application is a simple task management application with a MySQL backend. It allows users to add tasks, delete tasks, and view the list of tasks.

FEATURES:
Add tasks to the ToDo list.
Delete tasks from the ToDo list.
Store tasks in a MySQL database for persistence.

Getting Started:
Prerequisites:
Node.js: Download and install Node.js.
MySQL: Download and install MySQL.

Installation
1. Clone the repository:
git clone https://github.com/your-username/todo-app-mysql.git
cd todo-app-mysql

2. Backend Setup:
cd backend
npm install

3. Frontend Setup:
cd frontend
npm install

todo-app-mysql/
|-- backend/
|   |-- server.js
|   |-- package.json
|   |-- node_modules/
|
|-- frontend/
|   |-- src/
|       |-- App.js
|       |-- index.js
|   |-- public/
|   |-- package.json
|   |-- node_modules/

Backend (Node.js with Express and MySQL)
MySQL Database Setup
1. Create a MySQL Database:
Run the following SQL commands to create a database and a table:

CREATE DATABASE IF NOT EXISTS todo_db;
USE todo_db;

CREATE TABLE IF NOT EXISTS tasks (
  id INT AUTO_INCREMENT PRIMARY KEY,
  task VARCHAR(255) NOT NULL
);

2. MySQL Connection Configuration:

Update the MySQL connection details in backend/server.js.

Backend Routes
POST /addTask: Adds a task to the ToDo list. The task is stored in the MySQL database.

POST /deleteTask: Deletes a task from the ToDo list. The task is removed from the MySQL database.

GET /getTasks: Retrieves the list of tasks from the MySQL database.

Frontend (React)
Components
App.js: The main component containing the logic for adding tasks, deleting tasks, and rendering the task list.
API Integration
Axios: The frontend uses Axios for making HTTP requests to the backend.
Usage
Start MySQL Server:

Ensure that your MySQL server is running.

Create Database and Table:

Execute the provided SQL script to create the necessary database and table.

Update Connection Details:

Update the MySQL connection details in backend/server.js.

Start Backend:
cd backend
npm start
The backend server will be running at http://localhost:3001.

Start Frontend:
cd frontend
npm start

The frontend development server will be running at http://localhost:3000.

Open your browser:

Go to http://localhost:3000 to access the ToDo List application.



