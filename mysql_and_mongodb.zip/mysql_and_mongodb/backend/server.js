const express = require('express');
const cors = require('cors');
const mysql = require('mysql');
const bodyParser = require('body-parser');

const app = express();
const port = 3001;

app.use(bodyParser.json());
app.use(cors())
// Database connection
const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'todo_db',
});

connection.connect((err) => {
  if (err) {
    console.error('Error connecting to MySQL:', err);
    return;
  }
  console.log('Connected to MySQL');
});

// API to add a task
app.post('/addTask', (req, res) => {
  const task = req.body.task;
  const sql = 'INSERT INTO tasks (task) VALUES (?)';

  connection.query(sql, [task], (err, result) => {
    if (err) {
      console.error('Error adding task:', err);
      res.status(500).send('Internal Server Error');
      return;
    }

    res.status(200).send('Task added successfully');
  });
});

// API to delete a task
app.post('/deleteTask', (req, res) => {
  const taskId = req.body.id;
  const sql = 'DELETE FROM tasks WHERE id = ?';

  connection.query(sql, [taskId], (err, result) => {
    if (err) {
      console.error('Error deleting task:', err);
      res.status(500).send('Internal Server Error');
      return;
    }

    res.status(200).send('Task deleted successfully');
  });
});

// API to get all tasks
app.get('/getTasks', (req, res) => {
  const sql = 'SELECT * FROM tasks';

  connection.query(sql, (err, result) => {
    if (err) {
      console.error('Error fetching tasks:', err);
      res.status(500).send('Internal Server Error');
      return;
    }

    res.status(200).json({ tasks: result });
  });
});

app.listen(port, () => {
  console.log(`Backend server is running at http://localhost:${port}`);
});

// IMPORTANT NOTES!

// Please Add node_modules in both the backend and frontend. Run the npm install command before start the application and also start xampp server to cannect mysql database.